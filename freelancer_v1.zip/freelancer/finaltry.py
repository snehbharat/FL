from flask import Flask, render_template, request, jsonify
import requests
import os
import sys
sys.stdout.reconfigure(encoding='utf-8')

app = Flask(__name__)

# --- CONFIGURATION ---
GEMINI_API_KEY = "AIzaSyDJgWUgd6yfGVLn_F_Af94AA6f0kh8dZZg" 

# --- FLASK ROUTES ---
#SANDBOX_TOKEN = "rd0EBcHeqaaYN6vEhTIFMlxsPAgvDP"
PROD_TOKEN = "DnniVxFH5n3jsLRYwmlWcXRBcyVbJ3"
@app.route('/')
def index():
    """Renders the main user interface page."""
    return render_template('index.html')


@app.route('/search', methods=['POST'])
def search_projects():
    """
    Receives a search query from the user, fetches projects from Freelancer official API,
    processes them into a unified format, and returns as JSON.
    """
    data = request.get_json()
    query = data.get('query', "").strip() if data else ""
    minp=data.get('minPrice')
    maxp=data.get('maxPrice')
    limit=data.get('limit')
    project_types=data.get('project_type')
    
    #print(minp,maxp)
    #filters = data.get('filters', {}) 
    #print(filters)
    min_hourly = data.get('minHourly')
    max_hourly = data.get('maxHourly')


    
    
    #url='https://www.freelancer.com/api/projects/0.1/projects/active/?compact=&limit={limit}&job_details=&project_types%5B%5D=hourly&max_avg_hourly_rate=75&min_avg_hourly_rate=50&jobs%5B%5D=3'
    url = (
        "https://www.freelancer.com/api/projects/0.1/projects/active/"
        f"?compact=&limit={limit}&project_types%5B%5D={project_types}"
        f"&max_avg_price={maxp}%3D&min_avg_price={minp}&query={query}"
    )

    HEADERS = {
        "accept": "application/json",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Freelancer-OAuth-V1": PROD_TOKEN   
    }

    all_projects = []
    try:
        r = requests.get(url, headers=HEADERS, timeout=15)
        r.raise_for_status()
        data = r.json()

        if data.get('status') == 'success':
            all_projects = data.get("result", {}).get("projects", [])
        else:
            return jsonify({"error": data.get('message', "Unknown API error")}), 500
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Error fetching projects: {e}"}), 500

    
    projects = []
    for project in all_projects:
        budget_info = project.get('budget', {})
        currency_info = project.get('currency', {})

        budget_obj = {
            'minimum': budget_info.get('minimum', 0),
            'maximum': budget_info.get('maximum', 0)
        }
        currency_obj = {
            'code': currency_info.get('code', 'USD')
        }

        projects.append({
            'id': project.get('id'),
            'seo_url': project.get('seo_url'),
            'title': project.get("title", "N/A"),
            'description': project.get("preview_description", "").strip(),
            'budget': budget_obj,
            'currency': currency_obj
        })

    return jsonify(projects)
    

@app.route('/generate', methods=['POST'])
def generate_bid_route():
    """Receives a full project object and returns an AI-generated bid."""
    
    data = request.get_json()
    
    # Extract project and user details from the payload
    project = data.get('project', {})
    user_details = data.get('userDetails', {})
    
    project_description = project.get('description')
    project_title = project.get('title')
    project_budget = project.get('budget', {})

    if not all([project_description, project_title]):
        return jsonify({'error': 'Project title and description are required.'}), 400
    
    if not GEMINI_API_KEY:
         return jsonify({'error': 'Gemini API key is not configured on the server.'}), 500


    prompt = create_personalized_prompt(project, user_details)

    # --- GEMINI API CALL ---
    api_url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-05-20:generateContent?key={GEMINI_API_KEY}"
    headers = {'Content-Type': 'application/json'}
    payload = {"contents": [{"parts": [{"text": prompt}]}]}

    try:
        response = requests.post(api_url, headers=headers, json=payload, timeout=90)
        response.raise_for_status()
        result = response.json()
        
        if 'candidates' in result and result['candidates'][0]['content']['parts'][0]['text']:
            bid_text = result['candidates'][0]['content']['parts'][0]['text']
            return jsonify({'bid': bid_text})
        else:
            return jsonify({'error': "Could not extract the bid from the AI's response."}), 500

    except requests.exceptions.RequestException as e:
        return jsonify({'error': f'Failed to communicate with the AI service: {e}'}), 500
    
@app.route('/place_bid', methods=['POST'])
def place_bid():
    """Places the generated bid directly on Freelancer using the API"""
    data = request.get_json()

    project_id = data.get('project_id')
    bid_text = data.get('bid')
    amount = data.get('amount', 50)  # Default amount if not given
    period = data.get('period', 7)   # Default delivery days

    if not project_id or not bid_text:
        return jsonify({'error': 'Project ID and bid text required'}), 400
    
    url = "https://www.freelancer.com/api/users/0.1/self/"
    headers = {
        "Authorization": f"Bearer {PROD_TOKEN}",
        "Content-Type": "application/json"
    }

    try:
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        data = response.json()
        bidder_id = data["result"]["id"]
        print(f"Your bidder ID is: {bidder_id}")
        
    except requests.exceptions.RequestException as e:
        print(f"Failed to get bidder ID: {e}")
        

    #url = "https://www.freelancer-sandbox.com/api/projects/0.1/bids/"
    url = "https://www.freelancer.com/api/projects/0.1/bids/"
    headers = {
        #"Authorization": "Bearer rd0EBcHeqaaYN6vEhTIFMlxsPAgvDP",
        "Authorization" : "Bearer DnniVxFH5n3jsLRYwmlWcXRBcyVbJ3",
        "Content-Type" : "application/json",
        
        
    }

    payload = {
        "project_id": project_id,
        "bidder_id": bidder_id,
        "amount": amount,
        "period": period,
        "milestone_percentage": 100,
        "description": bid_text  # This will actually show up as your proposal
    }
    try:
        r = requests.post(url, headers=headers, json=payload, timeout=30)
        print(r.status_code, r.text)  # see what actually came back

        response_data = r.json()

        if r.status_code >= 400:
            return jsonify({
                'status': 'error',
                'message': response_data.get('message', 'Unknown error'),
                'error_code': response_data.get('error_code'),
                'request_id': response_data.get('request_id')
            }), r.status_code

        return jsonify(response_data)

    except requests.exceptions.RequestException as e:
        print(type(e), e)  # shows if it's a ConnectionError, Timeout, etc.
        return jsonify({'status': 'error', 'message': f'Failed to place bid: {e}'}), 500


'''
    try:
        r = requests.post(url, headers=headers, json=payload, timeout=30)
        r.raise_for_status()
        return jsonify(r.json())
    except requests.exceptions.RequestException as e:
        return jsonify({'error': f'Failed to place bid: {e}'}), 500
'''
def create_personalized_prompt(project, user_details):
    """Creates a personalized prompt based on project details and user information."""
    
    project_title = project.get('title', '')
    project_description = project.get('description', '')
    project_budget = project.get('budget', {})
    
    # Build budget information
    budget_info = ""
    if project_budget and project.get('currency'):
        currency = project.get('currency', {}).get('code', 'USD')
        min_budget = project_budget.get('minimum', 0)
        max_budget = project_budget.get('maximum', 0)
        if min_budget and max_budget:
            budget_info = f"\n**Project Budget:** {min_budget} - {max_budget} {currency}"
    
    # Build user profile section
    user_profile = ""
    if any(user_details.values()):  # Check if user provided any details
        user_profile = "\n**Your Profile:**"
        
        if user_details.get('name'):
            user_profile += f"\n- Name: {user_details['name']}"
        if user_details.get('title'):
            user_profile += f"\n- Professional Title: {user_details['title']}"
        if user_details.get('yearsExperience'):
            user_profile += f"\n- Years of Experience: {user_details['yearsExperience']}"
        if user_details.get('hourlyRate'):
            user_profile += f"\n- Preferred Hourly Rate: ${user_details['hourlyRate']}/hour"
        if user_details.get('keySkills'):
            user_profile += f"\n- Key Skills: {user_details['keySkills']}"
        if user_details.get('recentProjects'):
            user_profile += f"\n- Recent Similar Work: {user_details['recentProjects']}"
        if user_details.get('uniqueValue'):
            user_profile += f"\n- Unique Value Proposition: {user_details['uniqueValue']}"
    
    # Create the enhanced prompt
    prompt = f"""
You are an expert freelancer tasked with writing a winning, personalized project proposal.

**Project Title:** "{project_title}"

**Project Description:** "{project_description}"{budget_info}{user_profile}

**Instructions for creating a winning bid:**


1. **Professional Opening**: Start with a warm, professional greeting. If a name is provided, use it.

2. **Project Understanding**: Demonstrate clear understanding of the client's needs by summarizing the key requirements in your own words.

3. **Relevant Experience**: If experience/recent projects are provided, briefly mention how your background aligns with this project. If skills are listed, highlight the most relevant ones for this specific project.

4. **Value Proposition**: Confidently state how you'll deliver value. If unique selling points are provided, incorporate them naturally.

5. **Approach/Methodology**: Briefly outline your approach to completing this project successfully.

6. **Timeline & Communication**: Mention your commitment to timely delivery and good communication.

7. **Professional Closing**: End with a call to action inviting discussion. Sign off professionally using the provided name or "Best regards" if no name is given.

**Important Guidelines:**
- make the bid of minimum 100 characters and maximum 500
- Keep the tone professional yet personable
- Be confident but not overly pushy  
- Focus on value and results for the client
- If budget/rate information is provided, only mention pricing if it naturally fits the conversation
- Make it sound authentic and tailored to this specific project
- Avoid generic templates - make it feel personally written
- don't use bold letters and all as it shows with stars and does not look nice 
- avoid using em dashes and robotic language 
- make it sound as human and natural as possible 
- make short crisp and to the point and soo good that we land up the project and win the bid

Write a compelling proposal that wins the project:
"""

    return prompt


if __name__ == '__main__':
    app.run(debug=True)